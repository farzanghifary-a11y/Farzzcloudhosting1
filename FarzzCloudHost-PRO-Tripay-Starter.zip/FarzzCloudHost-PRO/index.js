require("dotenv").config();
const express = require("express");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, "[]");

const PACKAGES = {
  "1": { name: "Panel 1", price: 5000, days: 45, memory: 1024, disk: 5000, cpu: 50 },
  "2": { name: "Panel 2", price: 10000, days: 45, memory: 2048, disk: 10000, cpu: 75 },
  "3": { name: "Panel 3", price: 15000, days: 45, memory: 3072, disk: 15000, cpu: 100 },
  "4": { name: "Panel 4", price: 20000, days: 45, memory: 4096, disk: 20000, cpu: 125 },
  "5": { name: "Panel 5", price: 25000, days: 45, memory: 5120, disk: 25000, cpu: 150 },
  "6": { name: "Panel 6", price: 30000, days: 45, memory: 6144, disk: 30000, cpu: 175 },
  "7": { name: "Panel 7", price: 35000, days: 45, memory: 7168, disk: 35000, cpu: 200 }
};

function readOrders() {
  return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8"));
}
function writeOrders(rows) {
  const tmp = ORDERS_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(rows, null, 2));
  fs.renameSync(tmp, ORDERS_FILE);
}
function safeEqualHex(a, b) {
  if (!/^[a-f0-9]+$/i.test(a || "") || !/^[a-f0-9]+$/i.test(b || "")) return false;
  const aa = Buffer.from(a, "hex"), bb = Buffer.from(b, "hex");
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function makeRef() {
  return "FZ" + Date.now().toString() + crypto.randomBytes(3).toString("hex").toUpperCase();
}
function requireEnv(names) {
  const missing = names.filter((n) => !process.env[n]);
  if (missing.length) throw new Error("Missing environment variables: " + missing.join(", "));
}

app.use(express.static(path.join(__dirname, "public")));
app.get("/api/packages", (_req, res) => res.json(PACKAGES));

/*
 * Tripay callback MUST receive the untouched request body.
 * Keep this route before express.json().
 */
app.post("/api/payment/tripay/callback", express.raw({ type: "application/json" }), async (req, res) => {
  try {
    requireEnv(["TRIPAY_PRIVATE_KEY"]);
    const raw = req.body.toString("utf8");
    const received = req.get("X-Callback-Signature") || "";
    const expected = crypto.createHmac("sha256", process.env.TRIPAY_PRIVATE_KEY).update(raw).digest("hex");
    if (!safeEqualHex(received, expected)) return res.status(403).json({ success: false, message: "Invalid signature" });

    const event = req.get("X-Callback-Event");
    if (event !== "payment_status") return res.json({ success: true, message: "Ignored event" });

    const payload = JSON.parse(raw);
    const orders = readOrders();
    const order = orders.find((x) => x.merchantRef === payload.merchant_ref);
    if (!order) return res.status(404).json({ success: false, message: "Order not found" });

    // Never trust a callback alone: verify the reference, amount and final status.
    if (Number(payload.total_amount) !== Number(order.amount)) {
      return res.status(400).json({ success: false, message: "Amount mismatch" });
    }
    if (payload.status === "PAID" && order.status !== "PAID") {
      order.status = "PAID";
      order.paidAt = payload.paid_at || Math.floor(Date.now() / 1000);
      order.paymentReference = payload.reference || null;
      order.updatedAt = new Date().toISOString();
      writeOrders(orders);
      await provisionPaidOrder(order); // Connect Pterodactyl provisioning here.
    } else if (["FAILED", "EXPIRED", "REFUND"].includes(payload.status)) {
      order.status = payload.status;
      order.updatedAt = new Date().toISOString();
      writeOrders(orders);
    }
    return res.json({ success: true });
  } catch (err) {
    console.error("Tripay callback error:", err.message);
    return res.status(500).json({ success: false });
  }
});

app.use(express.json({ limit: "100kb" }));

app.post("/api/payment/create", async (req, res) => {
  try {
    requireEnv(["TRIPAY_API_KEY", "TRIPAY_PRIVATE_KEY", "TRIPAY_MERCHANT_CODE", "PUBLIC_BASE_URL"]);
    const { packageId, customerName, customerEmail, customerPhone } = req.body || {};
    const pack = PACKAGES[String(packageId)];
    if (!pack) return res.status(400).json({ error: "Paket tidak valid" });
    if (!customerName || !customerEmail) return res.status(400).json({ error: "Nama dan email wajib diisi" });

    const merchantRef = makeRef();
    const amount = pack.price;
    const signature = crypto.createHmac("sha256", process.env.TRIPAY_PRIVATE_KEY)
      .update(process.env.TRIPAY_MERCHANT_CODE + merchantRef + amount)
      .digest("hex");

    const body = new URLSearchParams({
      method: process.env.TRIPAY_PAYMENT_METHOD || "QRIS",
      merchant_ref: merchantRef,
      amount: String(amount),
      customer_name: String(customerName).slice(0, 100),
      customer_email: String(customerEmail).slice(0, 150),
      customer_phone: String(customerPhone || "").slice(0, 30),
      callback_url: process.env.PUBLIC_BASE_URL.replace(/\/$/, "") + "/api/payment/tripay/callback",
      return_url: process.env.PUBLIC_BASE_URL.replace(/\/$/, "") + "/?payment=return",
      expired_time: String(Math.floor(Date.now() / 1000) + 3600),
      signature
    });
    body.append("order_items[0][sku]", "FARZZ-PANEL-" + packageId);
    body.append("order_items[0][name]", pack.name + " - 45 hari");
    body.append("order_items[0][price]", String(amount));
    body.append("order_items[0][quantity]", "1");

    const sandbox = process.env.TRIPAY_MODE !== "production";
    const endpoint = sandbox
      ? "https://tripay.co.id/api-sandbox/transaction/create"
      : "https://tripay.co.id/api/transaction/create";

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + process.env.TRIPAY_API_KEY,
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json"
      },
      body
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      console.error("Tripay create failed:", result);
      return res.status(502).json({ error: "Gagal membuat pembayaran", detail: result.message || "Provider error" });
    }

    const data = result.data;
    const orders = readOrders();
    orders.push({
      merchantRef,
      packageId: String(packageId),
      packageName: pack.name,
      amount,
      days: pack.days,
      customerName,
      customerEmail,
      customerPhone: customerPhone || null,
      status: "UNPAID",
      paymentReference: data.reference || null,
      checkoutUrl: data.checkout_url || data.pay_url || null,
      qrUrl: data.qr_url || null,
      createdAt: new Date().toISOString()
    });
    writeOrders(orders);
    return res.json({
      success: true,
      merchantRef,
      amount,
      status: "UNPAID",
      checkoutUrl: data.checkout_url || data.pay_url || null,
      qrUrl: data.qr_url || null,
      instructions: "Selesaikan pembayaran. Panel hanya dibuat setelah callback pembayaran tervalidasi."
    });
  } catch (err) {
    console.error("Create payment error:", err.message);
    return res.status(500).json({ error: "Server belum dikonfigurasi atau terjadi kesalahan" });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "FarzzCloudHost" }));

async function provisionPaidOrder(order) {
  /*
   * TODO: Integrasi Pterodactyl Application API.
   * Implementasi harus:
   * 1. Cari/buat user berdasarkan email.
   * 2. Pilih egg dan allocation yang tersedia.
   * 3. Buat server dengan limit sesuai paket.
   * 4. Simpan serverId/clientIdentifier ke order.
   * Jangan pernah mengirim password root server induk ke pelanggan.
   */
  console.log("Payment confirmed; Pterodactyl provisioning pending:", order.merchantRef);
}

app.listen(PORT, () => console.log(`FarzzCloudHost running on port ${PORT}`));
