# FarzzCloudHost PRO — payment starter

Starter Node.js untuk katalog 7 paket panel dan pembuatan invoice Tripay.

## Isi
- `index.js`: Express API, daftar paket, create payment, callback signature verification.
- `public/index.html`: halaman demo sederhana.
- `.env.example`: template konfigurasi.
- Data order lokal disimpan di `data/orders.json` (untuk demo saja).

## Paket awal
Harga Rp5.000 sampai Rp35.000, masa aktif 45 hari. Limit RAM/CPU/disk pada kode hanyalah contoh konfigurasi paket; sesuaikan dengan kapasitas node dan kebijakan hosting.

## Menjalankan
```bash
cp .env.example .env
npm install
nano .env
npm run check
npm start
```

Gunakan Node.js 20+. `PUBLIC_BASE_URL` harus HTTPS dan dapat diakses publik agar callback provider bisa masuk.

## Tripay
1. Daftar merchant dan ambil API Key, Private Key, dan Merchant Code dari dashboard Tripay.
2. Mulai dengan `TRIPAY_MODE=sandbox`.
3. Atur callback URL di dashboard atau gunakan URL yang dikirim saat create transaction:
   `https://domain-kamu/api/payment/tripay/callback`
4. Pastikan channel `TRIPAY_PAYMENT_METHOD` aktif pada akun merchant.
5. Uji callback sandbox sampai signature dan status pembayaran terverifikasi, baru pindah ke production.

Dokumentasi resmi: https://tripay.co.id/developer

## Keamanan & batasan
- Jangan commit `.env`, API key, private key, token bot, atau credential Pterodactyl ke Git.
- Jangan percaya redirect browser sebagai bukti pembayaran. Status hanya berubah dari callback dengan signature valid dan jumlah yang cocok.
- File JSON bukan database produksi; ganti dengan PostgreSQL/MySQL dan transaksi/idempotency sebelum menerima pembayaran sungguhan.
- `provisionPaidOrder()` masih stub. Belum membuat server Pterodactyl sampai Application API, egg, allocation, resource limits, dan alur provisioning dikonfigurasi.
- Endpoint create payment ini starter/demo; tambahkan autentikasi, rate limiting, validasi email/nomor, CSRF bila memakai session, logging aman, dan proteksi abuse sebelum production.
- Git hosting hanya menyimpan kode. Node Pterodactyl/Wings harus berjalan di server yang kamu miliki/sewa.
